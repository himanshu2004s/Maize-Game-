#!/bin/bash

# Start All Services Script for VAHAN Chatbot

echo "🚀 Starting VAHAN Chatbot Services"
echo "==================================="

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Check if virtual environment exists
if [ ! -d "venv" ]; then
    echo -e "${YELLOW}⚠️  Virtual environment not found. Please run setup.sh first${NC}"
    exit 1
fi

# Activate virtual environment
source venv/bin/activate

# Create logs directory
mkdir -p logs

# Check if Ollama is running
if ! curl -s http://localhost:11434/api/tags &> /dev/null; then
    echo "Starting Ollama..."
    ollama serve &> logs/ollama.log &
    sleep 3
fi

# Start RASA action server
echo "Starting RASA Action Server..."
rasa run actions --port 5055 &> logs/rasa_actions.log &
ACTIONS_PID=$!
sleep 5

# Start RASA server
echo "Starting RASA Server..."
rasa run --enable-api --cors "*" --port 5005 &> logs/rasa_server.log &
RASA_PID=$!
sleep 5

# Start Flask backend
echo "Starting Flask Backend..."
python backend/app.py &> logs/flask.log &
FLASK_PID=$!
sleep 3

echo ""
echo "==================================="
echo -e "${GREEN}✅ All services started successfully!${NC}"
echo ""
echo "📊 Service Status:"
echo "  • Ollama: http://localhost:11434"
echo "  • RASA Actions: http://localhost:5055"
echo "  • RASA Server: http://localhost:5005"
echo "  • Flask Backend: http://localhost:5000"
echo ""
echo "🌐 Access Frontend:"
echo "  Open frontend/index.html in your browser"
echo "  or run: python -m http.server 8000 -d frontend/"
echo ""
echo "📝 Logs:"
echo "  • Ollama: logs/ollama.log"
echo "  • RASA Actions: logs/rasa_actions.log"
echo "  • RASA Server: logs/rasa_server.log"
echo "  • Flask: logs/flask.log"
echo ""
echo "🛑 To stop all services:"
echo "  ./scripts/stop_all.sh"
echo "  or press Ctrl+C and run: pkill -f \"rasa|flask\""
echo ""
echo "==================================="

# Save PIDs for stopping later
echo $ACTIONS_PID > logs/actions.pid
echo $RASA_PID > logs/rasa.pid
echo $FLASK_PID > logs/flask.pid

# Wait for all processes
wait
