#!/bin/bash

# Stop All Services Script for VAHAN Chatbot

echo "🛑 Stopping VAHAN Chatbot Services"
echo "==================================="

# Function to stop process by PID file
stop_process() {
    local pid_file=$1
    local service_name=$2
    
    if [ -f "$pid_file" ]; then
        local pid=$(cat "$pid_file")
        if ps -p $pid > /dev/null 2>&1; then
            echo "Stopping $service_name (PID: $pid)..."
            kill $pid
            sleep 2
            if ps -p $pid > /dev/null 2>&1; then
                echo "Force stopping $service_name..."
                kill -9 $pid
            fi
            rm "$pid_file"
            echo "✅ $service_name stopped"
        else
            echo "⚠️  $service_name not running"
            rm "$pid_file"
        fi
    else
        echo "⚠️  $service_name PID file not found"
    fi
}

# Stop services
stop_process "logs/actions.pid" "RASA Actions"
stop_process "logs/rasa.pid" "RASA Server"
stop_process "logs/flask.pid" "Flask Backend"

# Stop any remaining RASA or Flask processes
echo ""
echo "Cleaning up any remaining processes..."
pkill -f "rasa run" 2>/dev/null
pkill -f "flask" 2>/dev/null
pkill -f "backend/app.py" 2>/dev/null

echo ""
echo "==================================="
echo "✅ All services stopped"
echo "==================================="
