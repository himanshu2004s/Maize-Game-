"""
Database Handler for VAHAN Database
Handles secure database connections and query execution
"""

import logging
import re
from typing import List, Dict, Optional, Any
import psycopg2
from psycopg2.extras import RealDictCursor
import yaml

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class DatabaseHandler:
    """Handles secure database operations with read-only access"""
    
    # SQL injection patterns to block
    DANGEROUS_PATTERNS = [
        r'\bINSERT\b',
        r'\bUPDATE\b',
        r'\bDELETE\b',
        r'\bDROP\b',
        r'\bCREATE\b',
        r'\bALTER\b',
        r'\bTRUNCATE\b',
        r'\bEXEC\b',
        r'\bEXECUTE\b',
        r';.*SELECT',  # Multiple statements
        r'--',  # SQL comments
        r'/\*',  # SQL block comments
    ]
    
    # Maximum rows to return
    MAX_ROWS = 1000
    
    def __init__(self, config_path: str = "config/database_config.yaml"):
        """Initialize database connection"""
        self.config = self._load_config(config_path)
        self.connection = None
        
    def _load_config(self, config_path: str) -> Dict:
        """Load database configuration"""
        try:
            with open(config_path, 'r') as f:
                config = yaml.safe_load(f)
                return config.get('database', {})
        except Exception as e:
            logger.warning(f"Could not load config from {config_path}: {e}")
            # Return default localhost config
            return {
                'host': 'localhost',
                'port': 5432,
                'database': 'vahan_db',
                'user': 'vahan_readonly',
                'password': 'readonly_password'
            }
    
    def connect(self) -> bool:
        """Establish database connection"""
        try:
            self.connection = psycopg2.connect(
                host=self.config.get('host'),
                port=self.config.get('port'),
                database=self.config.get('database'),
                user=self.config.get('user'),
                password=self.config.get('password'),
                cursor_factory=RealDictCursor
            )
            logger.info("Database connected successfully")
            return True
        except Exception as e:
            logger.error(f"Database connection failed: {e}")
            return False
    
    def disconnect(self):
        """Close database connection"""
        if self.connection:
            self.connection.close()
            logger.info("Database disconnected")
    
    def validate_sql(self, sql: str) -> tuple[bool, Optional[str]]:
        """
        Validate SQL query for security
        
        Returns:
            (is_valid, error_message)
        """
        # Check for dangerous patterns
        for pattern in self.DANGEROUS_PATTERNS:
            if re.search(pattern, sql, re.IGNORECASE):
                return False, f"Dangerous SQL pattern detected: {pattern}"
        
        # Must be SELECT query
        if not sql.strip().upper().startswith('SELECT'):
            return False, "Only SELECT queries are allowed"
        
        # Check for multiple statements
        if sql.count(';') > 1:
            return False, "Multiple statements not allowed"
        
        # Limit row count
        if 'LIMIT' not in sql.upper():
            sql = sql.rstrip(';') + f' LIMIT {self.MAX_ROWS};'
        
        return True, None
    
    def execute_query(self, sql: str) -> Dict[str, Any]:
        """
        Execute SQL query and return results
        
        Returns:
            {
                'success': bool,
                'data': List[Dict],
                'row_count': int,
                'error': Optional[str]
            }
        """
        # Validate SQL
        is_valid, error = self.validate_sql(sql)
        if not is_valid:
            logger.warning(f"Invalid SQL rejected: {error}")
            return {
                'success': False,
                'data': [],
                'row_count': 0,
                'error': error
            }
        
        # Connect if not connected
        if not self.connection:
            if not self.connect():
                return {
                    'success': False,
                    'data': [],
                    'row_count': 0,
                    'error': 'Database connection failed'
                }
        
        try:
            cursor = self.connection.cursor()
            cursor.execute(sql)
            
            # Fetch results
            results = cursor.fetchall()
            row_count = len(results)
            
            cursor.close()
            
            logger.info(f"Query executed successfully. Rows returned: {row_count}")
            
            return {
                'success': True,
                'data': results,
                'row_count': row_count,
                'error': None
            }
            
        except Exception as e:
            logger.error(f"Query execution error: {e}")
            return {
                'success': False,
                'data': [],
                'row_count': 0,
                'error': str(e)
            }
    
    def format_results(self, results: Dict[str, Any]) -> str:
        """
        Format query results for display
        
        Args:
            results: Query execution results
            
        Returns:
            Formatted string for chatbot response
        """
        if not results['success']:
            return f"❌ Query failed: {results['error']}"
        
        if results['row_count'] == 0:
            return "No records found matching your query."
        
        data = results['data']
        row_count = results['row_count']
        
        # Format based on result type
        if row_count == 1 and len(data[0]) == 1:
            # Single value result (e.g., COUNT)
            value = list(data[0].values())[0]
            return f"Result: {value}"
        
        # Multiple rows - create formatted table
        response = f"📊 Found {row_count} record(s):\n\n"
        
        # Limit display to first 10 rows
        display_data = data[:10]
        
        for idx, row in enumerate(display_data, 1):
            response += f"Record {idx}:\n"
            for key, value in row.items():
                if value is not None:
                    response += f"  • {key}: {value}\n"
            response += "\n"
        
        if row_count > 10:
            response += f"... and {row_count - 10} more records.\n"
        
        return response


def test_database_connection():
    """Test database connection and query execution"""
    handler = DatabaseHandler()
    
    # Test connection
    if handler.connect():
        print("✅ Database connection successful")
        
        # Test query
        test_sql = "SELECT COUNT(*) as total FROM vt_owner;"
        result = handler.execute_query(test_sql)
        
        if result['success']:
            print(f"✅ Test query successful")
            print(handler.format_results(result))
        else:
            print(f"❌ Test query failed: {result['error']}")
        
        handler.disconnect()
    else:
        print("❌ Database connection failed")


if __name__ == "__main__":
    test_database_connection()
