"""
RASA Custom Actions for VAHAN Chatbot
Integrates Ollama SQL generation with database execution
"""

from typing import Any, Text, Dict, List
from rasa_sdk import Action, Tracker
from rasa_sdk.executor import CollectingDispatcher
from rasa_sdk.events import SlotSet
import logging

from actions.sql_generator import OllamaQueryGenerator
from actions.database_handler import DatabaseHandler

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class ActionQueryDatabase(Action):
    """Main action to handle database queries"""
    
    def __init__(self):
        super().__init__()
        self.sql_generator = OllamaQueryGenerator()
        self.db_handler = DatabaseHandler()
    
    def name(self) -> Text:
        return "action_query_database"
    
    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        
        # Get user message
        user_message = tracker.latest_message.get('text')
        
        # Get intent
        intent = tracker.latest_message.get('intent', {}).get('name')
        
        # Get entities
        entities = {}
        for entity in tracker.latest_message.get('entities', []):
            entities[entity['entity']] = entity['value']
        
        logger.info(f"Processing query - Intent: {intent}, Entities: {entities}")
        
        # Handle specific intents with predefined queries
        predefined_sql = self._get_predefined_query(intent, entities)
        
        if predefined_sql:
            sql_query = predefined_sql
            logger.info(f"Using predefined query: {sql_query}")
        else:
            # Generate SQL using Ollama
            dispatcher.utter_message(text="🔍 Analyzing your query...")
            sql_query = self.sql_generator.generate_sql(user_message, intent, entities)
            
            if not sql_query:
                dispatcher.utter_message(
                    text="I'm having trouble understanding that query. Could you rephrase it? "
                         "For example: 'Show vehicles from Delhi' or 'How many petrol vehicles?'"
                )
                return []
        
        # Execute query
        logger.info(f"Executing SQL: {sql_query}")
        results = self.db_handler.execute_query(sql_query)
        
        # Format and send response
        response = self.db_handler.format_results(results)
        dispatcher.utter_message(text=response)
        
        return []
    
    def _get_predefined_query(self, intent: str, entities: Dict) -> str:
        """Get predefined SQL for common queries"""
        
        # Vehicle by registration number
        if intent == "query_vehicle_by_registration" and "registration_number" in entities:
            reg_no = entities["registration_number"]
            return f"""
                SELECT v.regn_no, v.owner_name, v.f_name, v.maker_model, v.color, 
                       v.manu_yr, f.descr as fuel_type, n.descr as emission_norms,
                       v.state_cd, v.regn_dt
                FROM vt_owner v
                LEFT JOIN vm_fuel f ON v.fuel = f.code
                LEFT JOIN vm_norms n ON v.norms = n.code
                WHERE v.regn_no = '{reg_no}'
                LIMIT 1;
            """
        
        # Vehicle count
        if intent == "query_vehicle_count":
            return "SELECT COUNT(*) as total_vehicles FROM vt_owner;"
        
        # Vehicles by state
        if intent == "query_vehicles_by_state" and "state_code" in entities:
            state = entities["state_code"].upper()
            return f"""
                SELECT regn_no, owner_name, maker_model, color, regn_dt
                FROM vt_owner
                WHERE state_cd = '{state}'
                ORDER BY regn_dt DESC
                LIMIT 50;
            """
        
        # Vehicles by fuel type
        if intent == "query_vehicles_by_fuel_type" and "fuel_type" in entities:
            fuel = entities["fuel_type"].upper()
            return f"""
                SELECT v.regn_no, v.owner_name, v.maker_model, f.descr as fuel_type
                FROM vt_owner v
                JOIN vm_fuel f ON v.fuel = f.code
                WHERE UPPER(f.descr) LIKE '%{fuel}%'
                ORDER BY v.regn_dt DESC
                LIMIT 100;
            """
        
        # Vehicles by year
        if intent == "query_vehicles_by_year" and "year" in entities:
            year = entities["year"]
            return f"""
                SELECT regn_no, owner_name, maker_model, regn_dt
                FROM vt_owner
                WHERE EXTRACT(YEAR FROM regn_dt) = {year}
                ORDER BY regn_dt DESC
                LIMIT 100;
            """
        
        # Application status
        if intent == "query_application_status" and "application_number" in entities:
            appl_no = entities["application_number"]
            return f"""
                SELECT vd.appl_no, vd.appl_dt, vs.status, 
                       ta.action_descr, tp.descr as purpose,
                       vs.op_dt as last_updated
                FROM va_details vd
                JOIN va_status vs ON vd.appl_no = vs.appl_no
                LEFT JOIN tm_action ta ON vs.action_cd = ta.action_cd
                LEFT JOIN tm_purpose_mast tp ON vd.pur_cd = tp.pur_cd
                WHERE vd.appl_no = '{appl_no}'
                ORDER BY vs.op_dt DESC
                LIMIT 10;
            """
        
        # Pending applications
        if intent == "query_pending_applications":
            return """
                SELECT vd.appl_no, vd.appl_dt, tp.descr as purpose,
                       ta.action_descr, vs.op_dt
                FROM va_details vd
                JOIN va_status vs ON vd.appl_no = vs.appl_no
                LEFT JOIN tm_action ta ON vs.action_cd = ta.action_cd
                LEFT JOIN tm_purpose_mast tp ON vd.pur_cd = tp.pur_cd
                WHERE vs.status = 'N' OR vs.status = 'P'
                ORDER BY vd.appl_dt DESC
                LIMIT 50;
            """
        
        # Tax details
        if intent == "query_tax_details" and "registration_number" in entities:
            reg_no = entities["registration_number"]
            return f"""
                SELECT regn_no, tax_amt, tax_from, tax_upto, 
                       tax_fine, rcpt_no, rcpt_dt
                FROM vt_tax
                WHERE regn_no = '{reg_no}'
                ORDER BY tax_from DESC
                LIMIT 10;
            """
        
        # Insurance details
        if intent == "query_insurance_details" and "registration_number" in entities:
            reg_no = entities["registration_number"]
            return f"""
                SELECT regn_no, ins_from, ins_upto, policy_no, comp_cd
                FROM vt_insurance
                WHERE regn_no = '{reg_no}'
                ORDER BY ins_from DESC
                LIMIT 10;
            """
        
        # Expired insurance
        if intent == "query_vehicles_expired_insurance":
            return """
                SELECT v.regn_no, v.owner_name, i.ins_upto, i.policy_no
                FROM vt_owner v
                JOIN vt_insurance i ON v.regn_no = i.regn_no
                WHERE i.ins_upto < CURRENT_DATE
                ORDER BY i.ins_upto DESC
                LIMIT 50;
            """
        
        # Pending tax
        if intent == "query_vehicles_pending_tax":
            return """
                SELECT v.regn_no, v.owner_name, t.tax_upto, t.tax_amt
                FROM vt_owner v
                LEFT JOIN vt_tax t ON v.regn_no = t.regn_no
                WHERE t.tax_upto < CURRENT_DATE OR t.tax_upto IS NULL
                ORDER BY t.tax_upto
                LIMIT 50;
            """
        
        # Fuel type distribution
        if intent == "query_fuel_type_distribution":
            return """
                SELECT f.descr as fuel_type, COUNT(*) as vehicle_count
                FROM vt_owner v
                JOIN vm_fuel f ON v.fuel = f.code
                GROUP BY f.descr
                ORDER BY vehicle_count DESC;
            """
        
        # State-wise distribution
        if intent == "query_state_wise_distribution":
            return """
                SELECT state_cd, COUNT(*) as vehicle_count
                FROM vt_owner
                GROUP BY state_cd
                ORDER BY vehicle_count DESC
                LIMIT 50;
            """
        
        # Recent registrations
        if intent == "query_recent_registrations":
            return """
                SELECT regn_no, owner_name, maker_model, regn_dt, state_cd
                FROM vt_owner
                ORDER BY regn_dt DESC
                LIMIT 20;
            """
        
        return None


class ActionValidateInput(Action):
    """Validate user input before processing"""
    
    def name(self) -> Text:
        return "action_validate_input"
    
    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        
        # Get entities
        entities = tracker.latest_message.get('entities', [])
        
        # Validate registration number format
        for entity in entities:
            if entity['entity'] == 'registration_number':
                reg_no = entity['value']
                # Basic validation (can be enhanced)
                if len(reg_no) < 5:
                    dispatcher.utter_message(
                        text=f"The registration number '{reg_no}' seems invalid. "
                             "Please provide a valid format like 'DL01AB1234'"
                    )
                    return [SlotSet("registration_number", None)]
        
        return []


class ActionFormatResponse(Action):
    """Format database response for better readability"""
    
    def name(self) -> Text:
        return "action_format_response"
    
    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        
        # This action can be used for post-processing responses
        # Currently handled in ActionQueryDatabase
        
        return []
