"""
SQL Generator using Ollama Local LLM
Converts natural language queries to SQL with VAHAN database schema knowledge
"""

import re
import json
import logging
from typing import Dict, Optional
import requests

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Ollama configuration
OLLAMA_BASE_URL = "http://localhost:11434"
OLLAMA_MODEL = "llama3.2:3b"  # Change to your preferred model

# VAHAN Database Schema Context
DATABASE_SCHEMA = """
VAHAN Database Schema:

1. vt_owner (Vehicle Owner Table):
   - regn_no (TEXT, PRIMARY KEY): Vehicle registration number
   - state_cd (TEXT): State code (e.g., GA, DL, MH)
   - off_cd (TEXT): Office code
   - regn_dt (DATE): Registration date
   - owner_name (TEXT): Owner's name
   - f_name (TEXT): Father's name
   - fuel (INTEGER): Fuel type code (JOIN with vm_fuel.code)
   - maker (INTEGER): Manufacturer code
   - maker_model (TEXT): Vehicle model
   - color (TEXT): Vehicle color
   - manu_yr (INTEGER): Manufacturing year
   - norms (INTEGER): Emission norms code (JOIN with vm_norms.code)
   - vh_class (TEXT): Vehicle class
   - chasi_no (TEXT): Chassis number
   - eng_no (TEXT): Engine number

2. vm_fuel (Fuel Master Table):
   - code (INTEGER, PRIMARY KEY): Fuel type code
   - descr (TEXT): Fuel description (PETROL, DIESEL, CNG, ELECTRIC)

3. vm_norms (Emission Norms Master):
   - code (TEXT, PRIMARY KEY): Norms code
   - descr (TEXT): Norms description (BHARAT STAGE I, II, III, IV, VI)

4. va_details (Vehicle Application Details):
   - appl_no (TEXT, PRIMARY KEY): Application number
   - pur_cd (TEXT): Purpose code
   - appl_dt (TIMESTAMP): Application date
   - regn_no (TEXT): Registration number
   - state_cd (TEXT): State code
   - off_cd (TEXT): Office code

5. va_status (Application Status):
   - appl_no (TEXT): Application number
   - pur_cd (TEXT): Purpose code
   - action_cd (TEXT): Action code
   - status (TEXT): Status (N=New, P=Pending, C=Completed)
   - op_dt (TIMESTAMP): Operation date

6. tm_purpose_mast (Purpose Master):
   - pur_cd (TEXT, PRIMARY KEY): Purpose code
   - descr (TEXT): Purpose description
   - short_descr (TEXT): Short description

7. tm_action (Action Master):
   - action_cd (TEXT, PRIMARY KEY): Action code
   - action_descr (TEXT): Action description

8. vt_tax (Vehicle Tax):
   - regn_no (TEXT): Registration number
   - tax_amt (NUMERIC): Tax amount
   - tax_from (DATE): Tax valid from
   - tax_upto (DATE): Tax valid until
   - rcpt_no (TEXT): Receipt number
   - rcpt_dt (DATE): Receipt date

9. vt_insurance (Vehicle Insurance):
   - regn_no (TEXT): Registration number
   - ins_from (DATE): Insurance valid from
   - ins_upto (DATE): Insurance valid until
   - policy_no (TEXT): Policy number
   - comp_cd (TEXT): Company code

10. vt_fee (Vehicle Fee):
    - regn_no (TEXT): Registration number
    - fees (NUMERIC): Fee amount
    - fine (NUMERIC): Fine amount
    - pur_cd (TEXT): Purpose code
    - rcpt_dt (DATE): Receipt date

11. tm_office (Office Master):
    - off_cd (TEXT, PRIMARY KEY): Office code
    - off_name (TEXT): Office name
    - state_cd (TEXT): State code
    - dist_cd (TEXT): District code
"""

SQL_GENERATION_RULES = """
SQL Generation Rules:

1. ALWAYS use SELECT queries only (no INSERT, UPDATE, DELETE)
2. For fuel type queries, JOIN vt_owner with vm_fuel: vt_owner.fuel = vm_fuel.code
3. For emission norms, JOIN vt_owner with vm_norms: vt_owner.norms = vm_norms.code
4. For application details, JOIN va_details with va_status on appl_no
5. For purpose descriptions, JOIN with tm_purpose_mast on pur_cd
6. For action descriptions, JOIN with tm_action on action_cd
7. Use LIMIT 100 for safety unless specific limit requested
8. Use proper date comparisons with CAST or date functions
9. State codes are 2-letter uppercase (GA, DL, MH, etc.)
10. Return descriptive names, not codes (use JOINs)

Example Queries:

Q: "How many petrol vehicles are registered?"
A: SELECT COUNT(*) FROM vt_owner v JOIN vm_fuel f ON v.fuel = f.code WHERE f.descr = 'PETROL';

Q: "Show vehicles from Delhi"
A: SELECT regn_no, owner_name, maker_model FROM vt_owner WHERE state_cd = 'DL' LIMIT 100;

Q: "Application status for AN15070000000014"
A: SELECT vd.appl_no, vd.appl_dt, vs.status, ta.action_descr, tp.descr as purpose 
   FROM va_details vd 
   JOIN va_status vs ON vd.appl_no = vs.appl_no 
   LEFT JOIN tm_action ta ON vs.action_cd = ta.action_cd 
   LEFT JOIN tm_purpose_mast tp ON vd.pur_cd = tp.pur_cd 
   WHERE vd.appl_no = 'AN15070000000014';

Q: "Tax details for GA03X0157"
A: SELECT regn_no, tax_amt, tax_from, tax_upto, rcpt_no 
   FROM vt_tax 
   WHERE regn_no = 'GA03X0157' 
   ORDER BY tax_from DESC;
"""


class OllamaQueryGenerator:
    def __init__(self, base_url: str = OLLAMA_BASE_URL, model: str = OLLAMA_MODEL):
        self.base_url = base_url
        self.model = model
        self.endpoint = f"{base_url}/api/generate"
        
    def check_ollama_available(self) -> bool:
        """Check if Ollama service is running"""
        try:
            response = requests.get(f"{self.base_url}/api/tags", timeout=2)
            return response.status_code == 200
        except Exception as e:
            logger.error(f"Ollama not available: {e}")
            return False
    
    def generate_sql(self, natural_query: str, intent: str, entities: Dict) -> Optional[str]:
        """
        Generate SQL query from natural language using Ollama
        
        Args:
            natural_query: User's natural language query
            intent: Detected RASA intent
            entities: Extracted entities from RASA
            
        Returns:
            SQL query string or None if generation fails
        """
        if not self.check_ollama_available():
            logger.error("Ollama service is not running")
            return None
        
        # Build prompt with context
        prompt = self._build_prompt(natural_query, intent, entities)
        
        try:
            # Call Ollama API
            response = requests.post(
                self.endpoint,
                json={
                    "model": self.model,
                    "prompt": prompt,
                    "stream": False,
                    "options": {
                        "temperature": 0.1,  # Low temperature for consistency
                        "top_p": 0.9,
                        "max_tokens": 500
                    }
                },
                timeout=30
            )
            
            if response.status_code == 200:
                result = response.json()
                sql_query = self._extract_sql(result.get('response', ''))
                logger.info(f"Generated SQL: {sql_query}")
                return sql_query
            else:
                logger.error(f"Ollama API error: {response.status_code}")
                return None
                
        except Exception as e:
            logger.error(f"Error generating SQL: {e}")
            return None
    
    def _build_prompt(self, natural_query: str, intent: str, entities: Dict) -> str:
        """Build comprehensive prompt for Ollama"""
        
        # Extract entity values
        entity_str = ""
        if entities:
            entity_str = "\nExtracted Entities:\n"
            for entity_type, entity_value in entities.items():
                entity_str += f"- {entity_type}: {entity_value}\n"
        
        prompt = f"""{DATABASE_SCHEMA}

{SQL_GENERATION_RULES}

User Intent: {intent}
{entity_str}

User Query: "{natural_query}"

Generate ONLY the SQL query without any explanation. The query must:
1. Be syntactically correct PostgreSQL
2. Follow all the rules mentioned above
3. Use appropriate JOINs for descriptive data
4. Include LIMIT for safety
5. Be a SELECT statement only

SQL Query:"""
        
        return prompt
    
    def _extract_sql(self, response: str) -> Optional[str]:
        """Extract SQL query from Ollama response"""
        # Remove markdown code blocks if present
        sql = re.sub(r'```sql\n', '', response)
        sql = re.sub(r'```', '', sql)
        
        # Clean up
        sql = sql.strip()
        
        # Validate it's a SELECT query
        if not sql.upper().startswith('SELECT'):
            # Try to find SELECT in the response
            match = re.search(r'SELECT.*?;', sql, re.IGNORECASE | re.DOTALL)
            if match:
                sql = match.group(0)
            else:
                logger.warning("Generated query is not a SELECT statement")
                return None
        
        # Ensure query ends with semicolon
        if not sql.endswith(';'):
            sql += ';'
        
        return sql


def test_ollama_connection():
    """Test Ollama connection and model availability"""
    generator = OllamaQueryGenerator()
    if generator.check_ollama_available():
        print("✅ Ollama is running")
        
        # Test query generation
        test_query = "How many vehicles are registered?"
        result = generator.generate_sql(test_query, "query_vehicle_count", {})
        if result:
            print(f"✅ Test SQL generated: {result}")
        else:
            print("❌ Failed to generate test SQL")
    else:
        print("❌ Ollama is not running. Please start it with: ollama serve")


if __name__ == "__main__":
    test_ollama_connection()
