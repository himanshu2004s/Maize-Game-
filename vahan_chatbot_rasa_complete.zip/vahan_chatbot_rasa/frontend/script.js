// VAHAN Chatbot Frontend JavaScript

const API_BASE_URL = 'http://localhost:5000/api';
const USER_ID = 'user_' + Math.random().toString(36).substr(2, 9);

// DOM Elements
const chatMessages = document.getElementById('chatMessages');
const messageInput = document.getElementById('messageInput');
const sendBtn = document.getElementById('sendBtn');
const clearBtn = document.getElementById('clearBtn');
const helpBtn = document.getElementById('helpBtn');
const helpModal = document.getElementById('helpModal');
const closeModal = document.querySelector('.close');
const statusIndicator = document.getElementById('statusIndicator');
const statusText = document.getElementById('statusText');
const suggestions = document.querySelectorAll('.suggestion-btn');

// State
let isTyping = false;

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    checkHealth();
    setupEventListeners();
    adjustTextareaHeight();
});

// Event Listeners
function setupEventListeners() {
    // Send message on button click
    sendBtn.addEventListener('click', sendMessage);
    
    // Send message on Enter (Shift+Enter for new line)
    messageInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    });
    
    // Enable/disable send button based on input
    messageInput.addEventListener('input', () => {
        const hasText = messageInput.value.trim().length > 0;
        sendBtn.disabled = !hasText;
        adjustTextareaHeight();
    });
    
    // Clear chat
    clearBtn.addEventListener('click', clearChat);
    
    // Help modal
    helpBtn.addEventListener('click', () => {
        helpModal.style.display = 'block';
    });
    
    closeModal.addEventListener('click', () => {
        helpModal.style.display = 'none';
    });
    
    window.addEventListener('click', (e) => {
        if (e.target === helpModal) {
            helpModal.style.display = 'none';
        }
    });
    
    // Suggestion buttons
    suggestions.forEach(btn => {
        btn.addEventListener('click', () => {
            messageInput.value = btn.textContent;
            sendBtn.disabled = false;
            messageInput.focus();
        });
    });
}

// Check server health
async function checkHealth() {
    try {
        const response = await fetch(`${API_BASE_URL}/health`);
        const data = await response.json();
        
        if (data.rasa_connected) {
            statusIndicator.classList.add('connected');
            statusText.textContent = 'Connected';
        } else {
            statusIndicator.classList.add('error');
            statusText.textContent = 'RASA Server Not Connected';
        }
    } catch (error) {
        statusIndicator.classList.add('error');
        statusText.textContent = 'Backend Server Not Connected';
        console.error('Health check failed:', error);
    }
}

// Send message
async function sendMessage() {
    const message = messageInput.value.trim();
    
    if (!message || isTyping) return;
    
    // Add user message to chat
    addMessage(message, 'user');
    
    // Clear input
    messageInput.value = '';
    sendBtn.disabled = true;
    adjustTextareaHeight();
    
    // Show typing indicator
    showTypingIndicator();
    
    try {
        const response = await fetch(`${API_BASE_URL}/chat`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                message: message,
                user_id: USER_ID
            })
        });
        
        const data = await response.json();
        
        // Hide typing indicator
        hideTypingIndicator();
        
        if (data.success && data.messages) {
            // Add bot responses
            data.messages.forEach((msg, index) => {
                setTimeout(() => {
                    addMessage(msg.text, 'bot');
                }, index * 300); // Stagger messages
            });
        } else {
            addMessage(
                '❌ Sorry, I encountered an error. Please try again or check if the RASA server is running.',
                'bot'
            );
        }
        
    } catch (error) {
        hideTypingIndicator();
        addMessage(
            '❌ Connection error. Please ensure the backend server is running on port 5000.',
            'bot'
        );
        console.error('Send message error:', error);
    }
}

// Add message to chat
function addMessage(text, sender) {
    // Remove welcome message if exists
    const welcomeMsg = document.querySelector('.welcome-message');
    if (welcomeMsg) {
        welcomeMsg.remove();
    }
    
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${sender}`;
    
    const bubbleDiv = document.createElement('div');
    bubbleDiv.className = 'message-bubble';
    bubbleDiv.textContent = text;
    
    messageDiv.appendChild(bubbleDiv);
    chatMessages.appendChild(messageDiv);
    
    // Scroll to bottom
    scrollToBottom();
}

// Show typing indicator
function showTypingIndicator() {
    isTyping = true;
    
    const typingDiv = document.createElement('div');
    typingDiv.className = 'message bot';
    typingDiv.id = 'typingIndicator';
    
    const bubbleDiv = document.createElement('div');
    bubbleDiv.className = 'message-bubble';
    
    const indicatorDiv = document.createElement('div');
    indicatorDiv.className = 'typing-indicator';
    indicatorDiv.innerHTML = '<span></span><span></span><span></span>';
    
    bubbleDiv.appendChild(indicatorDiv);
    typingDiv.appendChild(bubbleDiv);
    chatMessages.appendChild(typingDiv);
    
    scrollToBottom();
}

// Hide typing indicator
function hideTypingIndicator() {
    isTyping = false;
    const indicator = document.getElementById('typingIndicator');
    if (indicator) {
        indicator.remove();
    }
}

// Clear chat
function clearChat() {
    if (confirm('Are you sure you want to clear the chat history?')) {
        // Clear messages except welcome
        chatMessages.innerHTML = `
            <div class="welcome-message">
                <h2>👋 Welcome to VAHAN Chatbot!</h2>
                <p>I can help you with:</p>
                <ul>
                    <li>🔍 Vehicle registration details</li>
                    <li>📋 Application status tracking</li>
                    <li>💰 Tax and insurance information</li>
                    <li>📊 Statistical queries and reports</li>
                </ul>
                <p>Try asking: <em>"Show vehicle details for GA03X0157"</em></p>
            </div>
        `;
        
        // Clear conversation on backend
        fetch(`${API_BASE_URL}/conversations/${USER_ID}`, {
            method: 'DELETE'
        }).catch(err => console.error('Clear conversation error:', err));
    }
}

// Scroll to bottom
function scrollToBottom() {
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

// Adjust textarea height
function adjustTextareaHeight() {
    messageInput.style.height = 'auto';
    messageInput.style.height = Math.min(messageInput.scrollHeight, 120) + 'px';
}

// Format timestamp
function formatTime(timestamp) {
    const date = new Date(timestamp);
    return date.toLocaleTimeString('en-US', { 
        hour: '2-digit', 
        minute: '2-digit' 
    });
}

// Periodically check health
setInterval(checkHealth, 30000); // Check every 30 seconds
