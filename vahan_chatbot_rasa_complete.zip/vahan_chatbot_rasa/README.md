# VAHAN Chatbot - RASA + Ollama (Local LLM)

## 🚗 Overview
VAHAN Chatbot is an AI-powered conversational system that allows users to query the VAHAN database using natural language. Built with RASA framework and Ollama (local LLM), ensuring complete data security and government compliance.

## 🏗️ Architecture

```
User
 ↓
Frontend (HTML/CSS/JS)
 ↓
Backend API (Flask)
 ↓
RASA Framework (NLU + Dialogue)
 ↓
Ollama (Local LLM - SQL Generation)
 ↓
SQL Validation & Security Layer
 ↓
Read-Only VAHAN Database (PostgreSQL)
```

## ✨ Features

- ✅ Natural language to SQL conversion
- ✅ Fully local LLM (No external APIs)
- ✅ Read-only database access
- ✅ VPN-based security
- ✅ Pre-trained with 50+ common queries
- ✅ Multi-table JOIN support
- ✅ Entity extraction (State, Registration Number, Date, etc.)
- ✅ Context-aware conversations

## 📦 Prerequisites

### System Requirements
- Python 3.8+
- PostgreSQL 12+
- Ollama installed locally
- 8GB RAM minimum (16GB recommended)

### Install Ollama
```bash
# Linux
curl -fsSL https://ollama.com/install.sh | sh

# Start Ollama service
ollama serve

# Pull required model (in another terminal)
ollama pull llama3.2:3b
```

## 🚀 Installation

### 1. Clone Repository
```bash
cd vahan_chatbot_rasa
```

### 2. Create Virtual Environment
```bash
python -m venv venv
source venv/bin/activate  # Linux/Mac
# OR
venv\Scripts\activate  # Windows
```

### 3. Install Dependencies
```bash
pip install -r requirements.txt
```

### 4. Database Setup
```bash
# Create database and import tables
python database/setup_database.py

# Or manually import CSV files
psql -U postgres -d vahan_db -c "\copy vt_owner FROM 'db_table/vt_owner.csv' DELIMITER ',' CSV HEADER"
# Repeat for all tables
```

### 5. Configure Database Connection
Edit `config/database_config.yaml`:
```yaml
database:
  host: "localhost"
  port: 5432
  database: "vahan_db"
  user: "vahan_readonly"
  password: "your_password"
```

### 6. Train RASA Model
```bash
rasa train
```

### 7. Run the System

#### Terminal 1: Start Ollama
```bash
ollama serve
```

#### Terminal 2: Start RASA Action Server
```bash
rasa run actions
```

#### Terminal 3: Start RASA Server
```bash
rasa run --enable-api --cors "*"
```

#### Terminal 4: Start Flask Backend
```bash
python backend/app.py
```

#### Terminal 5: Open Frontend
```bash
# Open frontend/index.html in browser
# OR run with simple HTTP server
python -m http.server 8000 -d frontend/
```

Access: http://localhost:8000

## 📚 Database Schema

### Main Tables
- **vt_owner**: Vehicle registration details
- **va_details**: Application details
- **va_status**: Application status tracking
- **vt_tax**: Tax information
- **vt_insurance**: Insurance details
- **vt_fee**: Fee records
- **tm_action**: Action master
- **tm_purpose_mast**: Purpose codes
- **tm_office**: Office details
- **vm_fuel**: Fuel types master
- **vm_norms**: Emission norms master

## 🎯 Pre-Trained Queries

The system is trained on 50+ common queries including:

### Vehicle Queries
- "How many petrol vehicles are registered?"
- "Show vehicles registered in Delhi"
- "Find vehicle details for registration number DL01AB1234"
- "List all diesel vehicles from 2023"

### Application Queries
- "Show pending applications"
- "Find application status for AN15070000000014"
- "How many new registration applications are there?"
- "List applications processed in December 2024"

### Tax & Insurance
- "Show tax details for vehicle GA03X0157"
- "Find vehicles with expired insurance"
- "List vehicles with pending tax"

### Analytics
- "Count vehicles by fuel type"
- "Show state-wise vehicle distribution"
- "Calculate total registration fee collected"

## 🔐 Security Features

1. **Read-Only Database Access**
   - Separate read-only user
   - SELECT queries only
   - No INSERT/UPDATE/DELETE

2. **SQL Validation Layer**
   - Query sanitization
   - Injection prevention
   - Result size limits

3. **VPN-Based Access**
   - Database accessible only via VPN
   - IP whitelisting

4. **Local LLM**
   - No external API calls
   - Complete data privacy

## 🛠️ Project Structure

```
vahan_chatbot_rasa/
├── data/
│   ├── nlu.yml              # Training data for intents
│   ├── stories.yml          # Conversation flows
│   └── rules.yml            # Dialogue rules
├── actions/
│   ├── actions.py           # Custom RASA actions
│   ├── sql_generator.py     # Ollama SQL generation
│   └── database_handler.py  # Database operations
├── config/
│   ├── config.yml           # RASA configuration
│   ├── domain.yml           # Domain definition
│   └── database_config.yaml # Database settings
├── frontend/
│   ├── index.html           # Web interface
│   ├── style.css            # Styling
│   └── script.js            # Frontend logic
├── backend/
│   ├── app.py               # Flask API server
│   └── security.py          # SQL validation
├── database/
│   ├── setup_database.py    # Database initialization
│   └── schemas.sql          # Table schemas
├── tests/
│   ├── test_queries.py      # Query testing
│   └── test_actions.py      # Action testing
├── models/                  # Trained RASA models
├── requirements.txt         # Python dependencies
└── README.md               # This file
```

## 🧪 Testing

### Test RASA NLU
```bash
rasa test nlu
```

### Test Conversations
```bash
rasa test
```

### Test Custom Actions
```bash
pytest tests/test_actions.py
```

### Interactive Testing
```bash
rasa shell
```

## 📝 Adding New Queries

### 1. Add Training Data
Edit `data/nlu.yml`:
```yaml
- intent: query_vehicle_count
  examples: |
    - How many vehicles are registered?
    - Total vehicle count
    - Number of registered vehicles
```

### 2. Add Story
Edit `data/stories.yml`:
```yaml
- story: vehicle count query
  steps:
  - intent: query_vehicle_count
  - action: action_query_database
```

### 3. Retrain Model
```bash
rasa train
```

## 🔧 Configuration

### Ollama Model Selection
Edit `actions/sql_generator.py`:
```python
OLLAMA_MODEL = "llama3.2:3b"  # Change model here
```

### Database Connection
Edit `config/database_config.yaml`

### RASA Pipeline
Edit `config/config.yml` for NLU pipeline customization

## 📊 Monitoring & Logs

Logs are stored in:
- RASA logs: `logs/rasa.log`
- Action logs: `logs/actions.log`
- Flask logs: `logs/flask.log`

## 🚨 Troubleshooting

### Ollama Not Running
```bash
# Check if Ollama is running
curl http://localhost:11434/api/tags

# Restart Ollama
ollama serve
```

### Database Connection Issues
```bash
# Test database connection
psql -U vahan_readonly -d vahan_db -h localhost

# Check PostgreSQL is running
sudo systemctl status postgresql
```

### RASA Training Fails
```bash
# Clean previous models
rm -rf models/*

# Retrain
rasa train --force
```

## 🤝 Contributing

1. Fork the repository
2. Create feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to branch (`git push origin feature/AmazingFeature`)
5. Open Pull Request

## 📄 License

This project is proprietary and confidential.

## 👥 Team

- **Architecture**: VAHAN Team
- **Development**: AI/ML Team
- **Database**: Infrastructure Team

## 📞 Support

For issues and queries:
- Email: support@vahan.gov.in
- Internal Slack: #vahan-chatbot

## 🗺️ Roadmap

- [ ] Voice-based query support
- [ ] Role-based access control
- [ ] PDF/Excel report generation
- [ ] Advanced analytics dashboard
- [ ] Multi-language support (Hindi, Tamil, etc.)
- [ ] Mobile app integration

---

**Version**: 1.0.0  
**Last Updated**: January 2026
