"""
Flask Backend for VAHAN Chatbot
Provides API endpoints for frontend communication with RASA
"""

from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import requests
import logging
from datetime import datetime

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

# RASA configuration
RASA_SERVER_URL = "http://localhost:5005"

# Store conversation history
conversations = {}


@app.route('/')
def index():
    """Serve frontend"""
    return """
    <html>
    <head><title>VAHAN Chatbot</title></head>
    <body>
        <h1>VAHAN Chatbot API Server</h1>
        <p>API is running. Access the frontend at <a href="/frontend">/frontend</a></p>
        <h2>Available Endpoints:</h2>
        <ul>
            <li>POST /api/chat - Send message to chatbot</li>
            <li>GET /api/health - Check server health</li>
            <li>GET /api/conversations/:user_id - Get conversation history</li>
        </ul>
    </body>
    </html>
    """


@app.route('/api/health', methods=['GET'])
def health_check():
    """Check if RASA server is running"""
    try:
        response = requests.get(f"{RASA_SERVER_URL}/status", timeout=2)
        rasa_status = response.status_code == 200
    except:
        rasa_status = False
    
    return jsonify({
        'status': 'healthy' if rasa_status else 'degraded',
        'timestamp': datetime.now().isoformat(),
        'rasa_connected': rasa_status
    })


@app.route('/api/chat', methods=['POST'])
def chat():
    """
    Handle chat messages
    
    Request body:
    {
        "message": "user message",
        "user_id": "unique_user_id"
    }
    
    Response:
    {
        "success": true,
        "messages": [
            {
                "text": "bot response",
                "timestamp": "..."
            }
        ]
    }
    """
    try:
        data = request.json
        message = data.get('message', '')
        user_id = data.get('user_id', 'default_user')
        
        if not message:
            return jsonify({
                'success': False,
                'error': 'Message is required'
            }), 400
        
        # Store user message in conversation history
        if user_id not in conversations:
            conversations[user_id] = []
        
        conversations[user_id].append({
            'sender': 'user',
            'text': message,
            'timestamp': datetime.now().isoformat()
        })
        
        # Send to RASA
        rasa_response = requests.post(
            f"{RASA_SERVER_URL}/webhooks/rest/webhook",
            json={
                'sender': user_id,
                'message': message
            },
            timeout=30
        )
        
        if rasa_response.status_code != 200:
            logger.error(f"RASA error: {rasa_response.text}")
            return jsonify({
                'success': False,
                'error': 'Failed to get response from chatbot'
            }), 500
        
        bot_messages = rasa_response.json()
        
        # Store bot messages in conversation history
        response_messages = []
        for msg in bot_messages:
            bot_message = {
                'sender': 'bot',
                'text': msg.get('text', ''),
                'timestamp': datetime.now().isoformat()
            }
            conversations[user_id].append(bot_message)
            response_messages.append(bot_message)
        
        logger.info(f"User: {user_id} | Message: {message} | Responses: {len(response_messages)}")
        
        return jsonify({
            'success': True,
            'messages': response_messages
        })
        
    except requests.exceptions.Timeout:
        logger.error("RASA request timeout")
        return jsonify({
            'success': False,
            'error': 'Request timeout. Please try again.'
        }), 504
        
    except requests.exceptions.ConnectionError:
        logger.error("RASA connection error")
        return jsonify({
            'success': False,
            'error': 'Cannot connect to chatbot service. Please ensure RASA is running.'
        }), 503
        
    except Exception as e:
        logger.error(f"Chat error: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'An unexpected error occurred'
        }), 500


@app.route('/api/conversations/<user_id>', methods=['GET'])
def get_conversation(user_id):
    """Get conversation history for a user"""
    if user_id not in conversations:
        return jsonify({
            'success': True,
            'messages': []
        })
    
    return jsonify({
        'success': True,
        'messages': conversations[user_id]
    })


@app.route('/api/conversations/<user_id>', methods=['DELETE'])
def clear_conversation(user_id):
    """Clear conversation history for a user"""
    if user_id in conversations:
        del conversations[user_id]
    
    return jsonify({
        'success': True,
        'message': 'Conversation cleared'
    })


@app.route('/api/stats', methods=['GET'])
def get_stats():
    """Get usage statistics"""
    total_conversations = len(conversations)
    total_messages = sum(len(conv) for conv in conversations.values())
    
    return jsonify({
        'total_conversations': total_conversations,
        'total_messages': total_messages,
        'active_users': list(conversations.keys())
    })


if __name__ == '__main__':
    print("🚀 Starting VAHAN Chatbot Backend Server")
    print(f"📡 RASA Server: {RASA_SERVER_URL}")
    print("🌐 Backend running on http://localhost:5000")
    print("\nMake sure RASA server is running before sending requests!")
    
    app.run(host='0.0.0.0', port=5000, debug=True)
