# VAHAN Chatbot Deployment Guide

## 📋 Table of Contents
1. [System Requirements](#system-requirements)
2. [Pre-Installation Setup](#pre-installation-setup)
3. [Installation Steps](#installation-steps)
4. [Configuration](#configuration)
5. [Starting the System](#starting-the-system)
6. [Testing](#testing)
7. [Troubleshooting](#troubleshooting)
8. [Production Deployment](#production-deployment)

## 🖥️ System Requirements

### Minimum Requirements
- **OS**: Ubuntu 20.04+ / CentOS 8+ / macOS 11+
- **RAM**: 8 GB
- **CPU**: 4 cores
- **Storage**: 20 GB free space
- **Python**: 3.8 or higher
- **PostgreSQL**: 12 or higher

### Recommended Requirements
- **RAM**: 16 GB
- **CPU**: 8 cores
- **Storage**: 50 GB SSD

## 🔧 Pre-Installation Setup

### 1. Install System Dependencies

#### Ubuntu/Debian
```bash
sudo apt update
sudo apt install -y python3 python3-pip python3-venv postgresql postgresql-contrib
```

#### CentOS/RHEL
```bash
sudo yum install -y python3 python3-pip postgresql postgresql-server
sudo postgresql-setup --initdb
sudo systemctl start postgresql
```

#### macOS
```bash
brew install python postgresql
brew services start postgresql
```

### 2. Install Ollama

#### Linux
```bash
curl -fsSL https://ollama.com/install.sh | sh
```

#### macOS
```bash
brew install ollama
```

#### Start Ollama and Download Model
```bash
# Start Ollama service
ollama serve &

# Download required model
ollama pull llama3.2:3b
```

### 3. Setup PostgreSQL

```bash
# Create database user
sudo -u postgres createuser vahan_readonly --pwprompt

# Create database
sudo -u postgres createdb vahan_db

# Grant permissions (will be done by setup script)
```

## 📦 Installation Steps

### 1. Clone/Extract Project
```bash
cd /path/to/vahan_chatbot_rasa
```

### 2. Run Setup Script
```bash
chmod +x setup.sh
./setup.sh
```

This script will:
- Check prerequisites
- Create virtual environment
- Install Python dependencies
- Train RASA model
- Create necessary directories

### 3. Setup Database Schema
```bash
# Activate virtual environment
source venv/bin/activate

# Edit database configuration
nano config/database_config.yaml

# Run database setup
python database/setup_database.py
```

## ⚙️ Configuration

### Database Configuration

Edit `config/database_config.yaml`:

```yaml
database:
  host: "localhost"
  port: 5432
  database: "vahan_db"
  user: "vahan_readonly"
  password: "your_secure_password"  # Change this!
```

### Ollama Configuration

Edit `actions/sql_generator.py` if you want to use a different model:

```python
OLLAMA_MODEL = "llama3.2:3b"  # Change to your preferred model
```

### RASA Configuration

The RASA configuration is in `config/config.yml`. Default settings should work well, but you can adjust:

- `epochs` in DIETClassifier and TEDPolicy for training duration
- `max_history` for context window
- Pipeline components for NLU customization

## 🚀 Starting the System

### Option 1: Using Start Script (Recommended)

```bash
chmod +x scripts/start_all.sh
./scripts/start_all.sh
```

### Option 2: Manual Start (for debugging)

Open 4 separate terminals:

**Terminal 1: Ollama**
```bash
ollama serve
```

**Terminal 2: RASA Actions**
```bash
source venv/bin/activate
rasa run actions --port 5055
```

**Terminal 3: RASA Server**
```bash
source venv/bin/activate
rasa run --enable-api --cors "*" --port 5005
```

**Terminal 4: Flask Backend**
```bash
source venv/bin/activate
python backend/app.py
```

**Terminal 5: Frontend**
```bash
# Option A: Direct file
open frontend/index.html

# Option B: HTTP Server
python -m http.server 8000 -d frontend/
# Then open http://localhost:8000
```

### Stopping the System

```bash
./scripts/stop_all.sh
```

## 🧪 Testing

### 1. Check System Health
```bash
curl http://localhost:5000/api/health
```

### 2. Run Query Tests
```bash
source venv/bin/activate
python tests/test_queries.py
```

### 3. Interactive RASA Shell
```bash
source venv/bin/activate
rasa shell
```

### 4. Test Individual Components

**Test Ollama:**
```bash
curl http://localhost:11434/api/tags
```

**Test RASA:**
```bash
curl http://localhost:5005/
```

**Test Backend:**
```bash
curl http://localhost:5000/api/health
```

## 🔍 Troubleshooting

### Common Issues

#### 1. Ollama Not Running
```bash
# Check if Ollama is running
curl http://localhost:11434/api/tags

# Start Ollama
ollama serve
```

#### 2. Database Connection Failed
```bash
# Check PostgreSQL is running
sudo systemctl status postgresql

# Test connection
psql -U vahan_readonly -d vahan_db -h localhost

# Check credentials in config/database_config.yaml
```

#### 3. RASA Training Fails
```bash
# Clear previous models
rm -rf models/*

# Retrain with verbose output
rasa train --debug
```

#### 4. Port Already in Use
```bash
# Find process using port
lsof -i :5005  # RASA
lsof -i :5055  # RASA Actions
lsof -i :5000  # Flask

# Kill process
kill -9 <PID>
```

#### 5. Frontend Cannot Connect
- Ensure all backend services are running
- Check browser console for errors
- Verify CORS is enabled in Flask backend
- Check API_BASE_URL in frontend/script.js

### Logs Location
```
logs/
├── ollama.log         # Ollama service logs
├── rasa_actions.log   # RASA action server logs
├── rasa_server.log    # RASA server logs
├── flask.log          # Flask backend logs
└── test_results.json  # Test results
```

## 🏭 Production Deployment

### 1. Security Hardening

#### Database Security
```sql
-- Create read-only user with restricted access
CREATE USER vahan_readonly WITH PASSWORD 'strong_password';
GRANT CONNECT ON DATABASE vahan_db TO vahan_readonly;
GRANT USAGE ON SCHEMA public TO vahan_readonly;
GRANT SELECT ON ALL TABLES IN SCHEMA public TO vahan_readonly;

-- Enable SSL for PostgreSQL connections
```

#### Environment Variables
```bash
# Create .env file
cat > .env << EOF
DB_HOST=localhost
DB_PORT=5432
DB_NAME=vahan_db
DB_USER=vahan_readonly
DB_PASSWORD=your_secure_password
FLASK_SECRET_KEY=your_secret_key
EOF

# Restrict permissions
chmod 600 .env
```

### 2. Use Process Manager (systemd)

Create service files:

**/etc/systemd/system/vahan-rasa-actions.service**
```ini
[Unit]
Description=VAHAN RASA Actions Server
After=network.target

[Service]
Type=simple
User=vahan
WorkingDirectory=/path/to/vahan_chatbot_rasa
Environment="PATH=/path/to/vahan_chatbot_rasa/venv/bin"
ExecStart=/path/to/vahan_chatbot_rasa/venv/bin/rasa run actions --port 5055
Restart=always

[Install]
WantedBy=multi-user.target
```

**/etc/systemd/system/vahan-rasa-server.service**
```ini
[Unit]
Description=VAHAN RASA Server
After=network.target vahan-rasa-actions.service

[Service]
Type=simple
User=vahan
WorkingDirectory=/path/to/vahan_chatbot_rasa
Environment="PATH=/path/to/vahan_chatbot_rasa/venv/bin"
ExecStart=/path/to/vahan_chatbot_rasa/venv/bin/rasa run --enable-api --cors "*" --port 5005
Restart=always

[Install]
WantedBy=multi-user.target
```

**/etc/systemd/system/vahan-backend.service**
```ini
[Unit]
Description=VAHAN Flask Backend
After=network.target vahan-rasa-server.service

[Service]
Type=simple
User=vahan
WorkingDirectory=/path/to/vahan_chatbot_rasa
Environment="PATH=/path/to/vahan_chatbot_rasa/venv/bin"
ExecStart=/path/to/vahan_chatbot_rasa/venv/bin/python backend/app.py
Restart=always

[Install]
WantedBy=multi-user.target
```

Enable and start services:
```bash
sudo systemctl daemon-reload
sudo systemctl enable vahan-rasa-actions vahan-rasa-server vahan-backend
sudo systemctl start vahan-rasa-actions vahan-rasa-server vahan-backend
```

### 3. Nginx Reverse Proxy

Install Nginx:
```bash
sudo apt install nginx
```

Configure Nginx (`/etc/nginx/sites-available/vahan-chatbot`):
```nginx
server {
    listen 80;
    server_name your-domain.com;

    # Frontend
    location / {
        root /path/to/vahan_chatbot_rasa/frontend;
        index index.html;
        try_files $uri $uri/ /index.html;
    }

    # Backend API
    location /api/ {
        proxy_pass http://localhost:5000/api/;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }

    # RASA Webhook
    location /webhooks/rest/webhook {
        proxy_pass http://localhost:5005/webhooks/rest/webhook;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

Enable site:
```bash
sudo ln -s /etc/nginx/sites-available/vahan-chatbot /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

### 4. SSL/TLS (Let's Encrypt)

```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d your-domain.com
```

### 5. Monitoring

#### Setup Monitoring
```bash
# Install monitoring tools
pip install prometheus-client

# Add metrics endpoint to Flask
# See backend/app.py for implementation
```

#### Health Check Endpoint
```bash
# Add to monitoring system
curl http://localhost:5000/api/health
```

### 6. Backup Strategy

```bash
# Automated database backup
0 2 * * * pg_dump -U postgres vahan_db > /backups/vahan_db_$(date +\%Y\%m\%d).sql

# Backup RASA models
0 3 * * * tar -czf /backups/rasa_models_$(date +\%Y\%m\%d).tar.gz /path/to/models/

# Keep only 30 days of backups
find /backups/ -name "*.sql" -mtime +30 -delete
```

## 📊 Performance Tuning

### 1. PostgreSQL Optimization
```sql
-- Increase shared buffers
ALTER SYSTEM SET shared_buffers = '4GB';

-- Increase work memory
ALTER SYSTEM SET work_mem = '256MB';

-- Increase maintenance work memory
ALTER SYSTEM SET maintenance_work_mem = '1GB';

-- Reload configuration
SELECT pg_reload_conf();
```

### 2. RASA Optimization
- Use GPU for faster inference (if available)
- Increase worker threads in production
- Enable caching for frequent queries

### 3. Ollama Optimization
- Use quantized models for faster inference
- Adjust context window size based on needs

## 📞 Support

For issues and questions:
- Check logs in `logs/` directory
- Review troubleshooting section
- Contact: support@vahan.gov.in

---

**Version**: 1.0.0  
**Last Updated**: January 2026
