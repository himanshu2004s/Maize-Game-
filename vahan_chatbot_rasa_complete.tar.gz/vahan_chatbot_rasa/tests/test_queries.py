"""
Test Script for VAHAN Chatbot Queries
Tests various query types to ensure system is working correctly
"""

import requests
import json
import time
from datetime import datetime

# Configuration
API_URL = "http://localhost:5000/api/chat"
USER_ID = "test_user"

# Test queries
TEST_QUERIES = [
    # Basic queries
    "hello",
    "how many vehicles are registered",
    "help",
    
    # Vehicle queries
    "show vehicle details for GA03X0157",
    "list vehicles from Goa",
    "how many petrol vehicles",
    "find diesel vehicles",
    
    # Application queries
    "show application status for AN15070000000014",
    "list pending applications",
    
    # Tax and insurance
    "show tax details for GA03X0157",
    "insurance details for GA03X0160",
    "vehicles with expired insurance",
    
    # Analytics
    "count vehicles by fuel type",
    "state-wise vehicle distribution",
    "recent registrations",
]


def test_query(query: str) -> dict:
    """Test a single query"""
    try:
        response = requests.post(
            API_URL,
            json={
                "message": query,
                "user_id": USER_ID
            },
            timeout=30
        )
        
        if response.status_code == 200:
            data = response.json()
            return {
                "success": True,
                "query": query,
                "response": data.get('messages', []),
                "error": None
            }
        else:
            return {
                "success": False,
                "query": query,
                "response": None,
                "error": f"HTTP {response.status_code}"
            }
    
    except Exception as e:
        return {
            "success": False,
            "query": query,
            "response": None,
            "error": str(e)
        }


def run_tests():
    """Run all test queries"""
    print("=" * 70)
    print("VAHAN CHATBOT QUERY TESTING")
    print("=" * 70)
    print(f"Started at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"Total queries to test: {len(TEST_QUERIES)}")
    print("=" * 70)
    print()
    
    results = []
    passed = 0
    failed = 0
    
    for i, query in enumerate(TEST_QUERIES, 1):
        print(f"[{i}/{len(TEST_QUERIES)}] Testing: {query}")
        
        result = test_query(query)
        results.append(result)
        
        if result['success']:
            passed += 1
            print(f"    ✅ SUCCESS")
            if result['response']:
                for msg in result['response']:
                    print(f"    💬 {msg.get('text', '')[:100]}...")
        else:
            failed += 1
            print(f"    ❌ FAILED: {result['error']}")
        
        print()
        time.sleep(1)  # Wait between requests
    
    # Summary
    print("=" * 70)
    print("TEST SUMMARY")
    print("=" * 70)
    print(f"Total Tests: {len(TEST_QUERIES)}")
    print(f"Passed: {passed} ({passed/len(TEST_QUERIES)*100:.1f}%)")
    print(f"Failed: {failed} ({failed/len(TEST_QUERIES)*100:.1f}%)")
    print("=" * 70)
    
    # Save results to file
    with open('logs/test_results.json', 'w') as f:
        json.dump({
            'timestamp': datetime.now().isoformat(),
            'total': len(TEST_QUERIES),
            'passed': passed,
            'failed': failed,
            'results': results
        }, f, indent=2)
    
    print(f"\nDetailed results saved to: logs/test_results.json")
    
    return passed == len(TEST_QUERIES)


if __name__ == "__main__":
    # Check if backend is accessible
    try:
        health = requests.get("http://localhost:5000/api/health", timeout=2)
        if health.status_code != 200:
            print("❌ Backend server is not responding")
            print("Please start the backend: python backend/app.py")
            exit(1)
    except:
        print("❌ Cannot connect to backend server")
        print("Please start the backend: python backend/app.py")
        exit(1)
    
    # Run tests
    success = run_tests()
    exit(0 if success else 1)
