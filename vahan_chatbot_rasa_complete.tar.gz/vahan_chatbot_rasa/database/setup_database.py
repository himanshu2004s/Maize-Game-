"""
Database Setup Script for VAHAN Chatbot
Creates database, tables, and imports CSV data
"""

import psycopg2
from psycopg2.extensions import ISOLATION_LEVEL_AUTOCOMMIT
import csv
import os
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Database configuration
DB_CONFIG = {
    'host': 'localhost',
    'port': 5432,
    'user': 'postgres',  # Admin user for setup
    'password': 'postgres'  # Change this
}

DB_NAME = 'vahan_db'
READONLY_USER = 'vahan_readonly'
READONLY_PASSWORD = 'readonly_password'  # Change this

CSV_DIR = '../db_table'  # Path to CSV files


def create_database():
    """Create VAHAN database"""
    try:
        # Connect to PostgreSQL
        conn = psycopg2.connect(**DB_CONFIG)
        conn.set_isolation_level(ISOLATION_LEVEL_AUTOCOMMIT)
        cursor = conn.cursor()
        
        # Drop database if exists
        cursor.execute(f"DROP DATABASE IF EXISTS {DB_NAME};")
        
        # Create database
        cursor.execute(f"CREATE DATABASE {DB_NAME};")
        
        cursor.close()
        conn.close()
        
        logger.info(f"✅ Database '{DB_NAME}' created successfully")
        return True
        
    except Exception as e:
        logger.error(f"❌ Failed to create database: {e}")
        return False


def create_tables():
    """Create all required tables"""
    
    # Connect to the new database
    conn = psycopg2.connect(**DB_CONFIG, database=DB_NAME)
    cursor = conn.cursor()
    
    try:
        # Create tables with proper schemas
        
        # vm_fuel (Fuel Master)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS vm_fuel (
                code INTEGER PRIMARY KEY,
                descr TEXT
            );
        """)
        
        # vm_norms (Emission Norms Master)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS vm_norms (
                code TEXT PRIMARY KEY,
                descr TEXT
            );
        """)
        
        # vt_owner (Vehicle Owner)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS vt_owner (
                state_cd TEXT,
                off_cd TEXT,
                regn_no TEXT PRIMARY KEY,
                regn_dt DATE,
                purchase_dt DATE,
                owner_sr TEXT,
                owner_name TEXT,
                f_name TEXT,
                c_add1 TEXT,
                c_add2 TEXT,
                c_add3 TEXT,
                c_district TEXT,
                c_pincode TEXT,
                c_state TEXT,
                p_add1 TEXT,
                p_add2 TEXT,
                p_add3 TEXT,
                p_district TEXT,
                p_pincode TEXT,
                p_state TEXT,
                owner_cd TEXT,
                regn_type TEXT,
                vh_class TEXT,
                chasi_no TEXT,
                eng_no TEXT,
                maker TEXT,
                maker_model TEXT,
                body_type TEXT,
                no_cyl TEXT,
                hp TEXT,
                seat_cap TEXT,
                stand_cap TEXT,
                sleeper_cap TEXT,
                unld_wt TEXT,
                ld_wt TEXT,
                gcw TEXT,
                fuel INTEGER,
                color TEXT,
                manu_mon TEXT,
                manu_yr INTEGER,
                norms TEXT,
                wheelbase TEXT,
                cubic_cap TEXT,
                floor_area TEXT,
                ac_fitted TEXT,
                audio_fitted TEXT,
                video_fitted TEXT,
                vch_purchase_as TEXT,
                vch_catg TEXT,
                dealer_cd TEXT,
                sale_amt TEXT,
                laser_code TEXT,
                garage_add TEXT,
                length TEXT,
                width TEXT,
                height TEXT,
                regn_upto DATE,
                fit_upto DATE,
                annual_income TEXT,
                imported_vch TEXT,
                other_criteria TEXT,
                status TEXT,
                op_dt TIMESTAMP
            );
        """)
        
        # tm_purpose_mast (Purpose Master)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS tm_purpose_mast (
                pur_cd TEXT PRIMARY KEY,
                descr TEXT,
                short_descr TEXT,
                fee_type TEXT,
                inward_appl TEXT,
                amt_from_wsdl BOOLEAN,
                balance_fee BOOLEAN,
                is_primery_service BOOLEAN
            );
        """)
        
        # tm_action (Action Master)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS tm_action (
                action_cd TEXT PRIMARY KEY,
                action_descr TEXT,
                action_abbrv TEXT,
                dl_rc_scope TEXT,
                role_cd TEXT,
                redirect_menu TEXT,
                redirect_url TEXT,
                state_cd TEXT,
                user_catg TEXT,
                action_under_project TEXT
            );
        """)
        
        # tm_office (Office Master)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS tm_office (
                off_cd TEXT,
                off_name TEXT,
                off_add1 TEXT,
                off_add2 TEXT,
                pin_cd TEXT,
                village_cd TEXT,
                taluk_cd TEXT,
                dist_cd TEXT,
                mobile_no TEXT,
                landline TEXT,
                email_id TEXT,
                off_under_cd TEXT,
                off_type_cd TEXT,
                state_cd TEXT,
                PRIMARY KEY (off_cd, state_cd)
            );
        """)
        
        # va_details (Application Details)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS va_details (
                appl_no TEXT PRIMARY KEY,
                pur_cd TEXT,
                appl_dt TIMESTAMP,
                regn_no TEXT,
                user_id TEXT,
                user_type TEXT,
                entry_ip TEXT,
                entry_status TEXT,
                confirm_ip TEXT,
                confirm_status TEXT,
                confirm_date TIMESTAMP,
                state_cd TEXT,
                off_cd TEXT
            );
        """)
        
        # va_status (Application Status)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS va_status (
                state_cd TEXT,
                off_cd TEXT,
                appl_no TEXT,
                pur_cd TEXT,
                flow_slno TEXT,
                file_movement_slno TEXT,
                action_cd TEXT,
                seat_cd TEXT,
                cntr_id TEXT,
                status TEXT,
                office_remark TEXT,
                public_remark TEXT,
                file_movement_type TEXT,
                emp_cd TEXT,
                op_dt TIMESTAMP,
                PRIMARY KEY (appl_no, flow_slno)
            );
        """)
        
        # vt_tax (Vehicle Tax)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS vt_tax (
                regn_no TEXT,
                tax_mode TEXT,
                payment_mode TEXT,
                tax_amt NUMERIC,
                tax_fine NUMERIC,
                rcpt_no TEXT,
                rcpt_dt TIMESTAMP,
                tax_from DATE,
                tax_upto DATE,
                pur_cd TEXT,
                flag TEXT,
                collected_by TEXT,
                state_cd TEXT,
                off_cd TEXT
            );
        """)
        
        # vt_insurance (Vehicle Insurance)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS vt_insurance (
                state_cd TEXT,
                off_cd TEXT,
                regn_no TEXT,
                comp_cd TEXT,
                ins_type TEXT,
                ins_from DATE,
                ins_upto DATE,
                policy_no TEXT,
                idv TEXT,
                op_dt TIMESTAMP
            );
        """)
        
        # vt_fee (Vehicle Fee)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS vt_fee (
                regn_no TEXT,
                payment_mode TEXT,
                fees NUMERIC,
                fine NUMERIC,
                rcpt_no TEXT,
                rcpt_dt TIMESTAMP,
                pur_cd TEXT,
                flag TEXT,
                collected_by TEXT,
                state_cd TEXT,
                off_cd TEXT
            );
        """)
        
        # tm_role (Role Master)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS tm_role (
                role_cd TEXT PRIMARY KEY,
                role_descr TEXT,
                user_catg TEXT
            );
        """)
        
        conn.commit()
        cursor.close()
        conn.close()
        
        logger.info("✅ All tables created successfully")
        return True
        
    except Exception as e:
        logger.error(f"❌ Failed to create tables: {e}")
        conn.rollback()
        return False


def import_csv_data():
    """Import data from CSV files"""
    
    conn = psycopg2.connect(**DB_CONFIG, database=DB_NAME)
    cursor = conn.cursor()
    
    csv_files = {
        'vm_fuel.csv': 'vm_fuel',
        'vm_norms.csv': 'vm_norms',
        'vt_owner.csv': 'vt_owner',
        'tm_purpose_mast.csv': 'tm_purpose_mast',
        'tm_action.csv': 'tm_action',
        'tm_office.csv': 'tm_office',
        'va_details.csv': 'va_details',
        'va_status.csv': 'va_status',
        'vt_tax.csv': 'vt_tax',
        'vt_insurance.csv': 'vt_insurance',
        'vt_fee.csv': 'vt_fee',
        'tm_role.csv': 'tm_role'
    }
    
    for csv_file, table_name in csv_files.items():
        csv_path = os.path.join(CSV_DIR, csv_file)
        
        if not os.path.exists(csv_path):
            logger.warning(f"⚠️  CSV file not found: {csv_path}")
            continue
        
        try:
            with open(csv_path, 'r', encoding='utf-8') as f:
                cursor.copy_expert(
                    f"COPY {table_name} FROM STDIN WITH CSV HEADER DELIMITER ','",
                    f
                )
            
            conn.commit()
            logger.info(f"✅ Imported data into {table_name}")
            
        except Exception as e:
            logger.error(f"❌ Failed to import {csv_file}: {e}")
            conn.rollback()
    
    cursor.close()
    conn.close()


def create_readonly_user():
    """Create read-only user for security"""
    
    conn = psycopg2.connect(**DB_CONFIG, database=DB_NAME)
    conn.set_isolation_level(ISOLATION_LEVEL_AUTOCOMMIT)
    cursor = conn.cursor()
    
    try:
        # Create user
        cursor.execute(f"""
            DO $$
            BEGIN
                IF NOT EXISTS (SELECT FROM pg_user WHERE usename = '{READONLY_USER}') THEN
                    CREATE USER {READONLY_USER} WITH PASSWORD '{READONLY_PASSWORD}';
                END IF;
            END
            $$;
        """)
        
        # Grant read-only permissions
        cursor.execute(f"GRANT CONNECT ON DATABASE {DB_NAME} TO {READONLY_USER};")
        cursor.execute(f"GRANT USAGE ON SCHEMA public TO {READONLY_USER};")
        cursor.execute(f"GRANT SELECT ON ALL TABLES IN SCHEMA public TO {READONLY_USER};")
        cursor.execute(f"ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT ON TABLES TO {READONLY_USER};")
        
        cursor.close()
        conn.close()
        
        logger.info(f"✅ Read-only user '{READONLY_USER}' created")
        return True
        
    except Exception as e:
        logger.error(f"❌ Failed to create readonly user: {e}")
        return False


def main():
    """Main setup function"""
    print("🚀 Starting VAHAN Database Setup...\n")
    
    # Step 1: Create database
    print("📦 Creating database...")
    if not create_database():
        return
    
    # Step 2: Create tables
    print("\n📊 Creating tables...")
    if not create_tables():
        return
    
    # Step 3: Import data
    print("\n📥 Importing CSV data...")
    import_csv_data()
    
    # Step 4: Create readonly user
    print("\n🔐 Creating read-only user...")
    create_readonly_user()
    
    print("\n✅ Database setup completed successfully!")
    print(f"\nDatabase: {DB_NAME}")
    print(f"Read-only User: {READONLY_USER}")
    print("\nYou can now configure your chatbot to use this database.")


if __name__ == "__main__":
    main()
