#!/bin/bash

# VAHAN Chatbot Setup Script
# This script helps set up the entire VAHAN chatbot system

echo "🚀 VAHAN Chatbot Setup Script"
echo "================================"
echo ""

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Function to print colored output
print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

# Check if Python is installed
echo "📦 Checking prerequisites..."
if ! command -v python3 &> /dev/null; then
    print_error "Python 3 is not installed. Please install Python 3.8 or higher."
    exit 1
fi
print_success "Python 3 is installed"

# Check if pip is installed
if ! command -v pip3 &> /dev/null; then
    print_error "pip3 is not installed. Please install pip3."
    exit 1
fi
print_success "pip3 is installed"

# Check if PostgreSQL is installed
if ! command -v psql &> /dev/null; then
    print_warning "PostgreSQL is not installed or not in PATH"
    echo "You'll need to install PostgreSQL manually"
else
    print_success "PostgreSQL is installed"
fi

# Check if Ollama is installed
echo ""
echo "🤖 Checking Ollama installation..."
if ! command -v ollama &> /dev/null; then
    print_error "Ollama is not installed"
    echo "Please install Ollama from: https://ollama.com/download"
    echo "After installation, run: ollama pull llama3.2:3b"
    exit 1
fi
print_success "Ollama is installed"

# Check if Ollama is running
if ! curl -s http://localhost:11434/api/tags &> /dev/null; then
    print_warning "Ollama is not running"
    echo "Starting Ollama in background..."
    ollama serve &> /dev/null &
    sleep 3
    if curl -s http://localhost:11434/api/tags &> /dev/null; then
        print_success "Ollama started successfully"
    else
        print_error "Failed to start Ollama. Please start it manually: ollama serve"
        exit 1
    fi
else
    print_success "Ollama is running"
fi

# Check if required model is available
echo ""
echo "📥 Checking Ollama model..."
if ollama list | grep -q "llama3.2:3b"; then
    print_success "llama3.2:3b model is available"
else
    print_warning "llama3.2:3b model not found"
    echo "Downloading model (this may take a few minutes)..."
    ollama pull llama3.2:3b
    if [ $? -eq 0 ]; then
        print_success "Model downloaded successfully"
    else
        print_error "Failed to download model"
        exit 1
    fi
fi

# Create virtual environment
echo ""
echo "🐍 Setting up Python virtual environment..."
if [ -d "venv" ]; then
    print_warning "Virtual environment already exists"
else
    python3 -m venv venv
    print_success "Virtual environment created"
fi

# Activate virtual environment
source venv/bin/activate

# Upgrade pip
echo ""
echo "📦 Upgrading pip..."
pip install --upgrade pip --quiet

# Install requirements
echo ""
echo "📚 Installing Python dependencies..."
echo "This may take several minutes..."
pip install -r requirements.txt --quiet
if [ $? -eq 0 ]; then
    print_success "Dependencies installed successfully"
else
    print_error "Failed to install dependencies"
    exit 1
fi

# Create necessary directories
echo ""
echo "📁 Creating directories..."
mkdir -p logs
mkdir -p models
print_success "Directories created"

# Check database configuration
echo ""
echo "🗄️  Database Configuration"
if [ ! -f "config/database_config.yaml" ]; then
    print_warning "Database configuration file not found"
    echo "Please configure your database in config/database_config.yaml"
else
    print_success "Database configuration file exists"
fi

# Train RASA model
echo ""
echo "🎓 Training RASA model..."
echo "This may take several minutes..."
rasa train
if [ $? -eq 0 ]; then
    print_success "RASA model trained successfully"
else
    print_error "Failed to train RASA model"
    exit 1
fi

# Final instructions
echo ""
echo "================================"
print_success "Setup completed successfully!"
echo ""
echo "📝 Next Steps:"
echo ""
echo "1. Configure database (if not done):"
echo "   Edit config/database_config.yaml with your database credentials"
echo ""
echo "2. Set up database schema:"
echo "   python database/setup_database.py"
echo ""
echo "3. Start the system:"
echo "   Terminal 1: ollama serve"
echo "   Terminal 2: rasa run actions"
echo "   Terminal 3: rasa run --enable-api --cors \"*\""
echo "   Terminal 4: python backend/app.py"
echo "   Terminal 5: Open frontend/index.html in browser"
echo ""
echo "4. Or use the provided start script:"
echo "   ./scripts/start_all.sh"
echo ""
echo "================================"
