# VAHAN Chatbot - Quick Start Guide

## 🚀 5-Minute Setup

### Prerequisites Check
```bash
# Check Python version (needs 3.8+)
python3 --version

# Check PostgreSQL
psql --version

# Check Ollama
ollama --version
```

### Step 1: Install Ollama (if not installed)
```bash
# Linux/Mac
curl -fsSL https://ollama.com/install.sh | sh

# Start Ollama
ollama serve &

# Download model
ollama pull llama3.2:3b
```

### Step 2: Run Setup Script
```bash
cd vahan_chatbot_rasa
chmod +x setup.sh
./setup.sh
```

### Step 3: Configure Database
```bash
# Edit database config
nano config/database_config.yaml

# Update these values:
# - host: your_db_host
# - database: vahan_db
# - user: vahan_readonly
# - password: your_password
```

### Step 4: Setup Database Schema
```bash
source venv/bin/activate
python database/setup_database.py
```

### Step 5: Start All Services
```bash
chmod +x scripts/start_all.sh
./scripts/start_all.sh
```

### Step 6: Open Frontend
Open `frontend/index.html` in your web browser or:
```bash
python -m http.server 8000 -d frontend/
# Then open http://localhost:8000
```

## 🎯 Test the System

Try these queries in the chatbot:
- "How many vehicles are registered?"
- "Show vehicle details for GA03X0157"
- "List vehicles from Delhi"
- "Show pending applications"

## 🛑 Stop the System
```bash
./scripts/stop_all.sh
```

## 📚 Next Steps

1. Read the full [README.md](README.md) for detailed information
2. Check [DEPLOYMENT.md](DEPLOYMENT.md) for production setup
3. See `tests/test_queries.py` for testing examples

## ❓ Common Issues

### "Ollama not running"
```bash
ollama serve
```

### "Cannot connect to database"
- Check PostgreSQL is running: `sudo systemctl status postgresql`
- Verify credentials in `config/database_config.yaml`

### "RASA training failed"
```bash
rm -rf models/*
rasa train --debug
```

## 📞 Support
- Logs: Check `logs/` directory
- Email: support@vahan.gov.in
